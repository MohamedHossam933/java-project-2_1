package school;

import java.util.*;
import static school.db.*;

public class School {

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("All Data");
        System.out.println("=======================");
        db.fillAll();
        System.out.println();
        System.out.println("=======================");
        System.out.println("Max Grade of each class");
        System.out.println("=======================");
        Max_grades();
        System.out.println();
        System.out.println("=======================");
        System.out.println("Sorted grades");
        System.out.println("=======================");
        sort_grades();
        System.out.println("=======================");
        System.out.println("Sorted ages");
        System.out.println("=======================");
        sort_ages();
    }

}
